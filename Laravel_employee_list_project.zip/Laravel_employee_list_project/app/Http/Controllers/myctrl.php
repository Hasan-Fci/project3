<?php

namespace App\Http\Controllers;

use DB;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use Session;

session_start();
class myctrl extends Controller {
	public function adminview() {
		return view('admin/admin_home');
	}

	public function employee() {
		return view('admin/employee');
	}

	public function listemployee() {
		return view('admin/all_employee');
	}

	public function save_employee(Request $request) {
		$data = array();
		$data['Name'] = $request->emp_name;
		$data['Email'] = $request->emp_email;
		$data['Position'] = $request->emp_pst;
		$data['Address'] = $request->emp_adrs;
		$data['Phone'] = $request->emp_nmbr;
		DB::table('employee')->insert($data);
		Session::put('massage', 'Employee Add Successfully !!!');
		//return Redirect::to('/employee');
		return Redirect::to('/all_employee');
	}

	public function all_list(Request $request) {
		$students = DB::table('employee')->get();
		return view('admin/all_employee', ['datatable' => $students]);

	}

	public function delete_employee($delete_id) {
		DB::table('employee')->where('id', $delete_id)->delete();
		Session::put('massage', 'Employee Delete Successfully !!!');
		return Redirect::to('/all_employee');
	}

	public function update_employee($id) {
		$data = DB::table('employee')->where('id', $id)->first();
		return view('admin.update', ['emp' => $data]);

	}

	public function update(Request $request) {
		$data = DB::table('employee')->where('id', $request->id)->update(['Name' => $request->emp_name, 'Email' => $request->emp_email, 'Position' => $request->emp_pst, 'Address' => $request->emp_adrs, 'Phone' => $request->emp_nmbr]);
		if ($data) {
			Session::put('massage', 'Employee update Successfully !!!');
			return Redirect::to('/all_employee');
		}

	}

}
