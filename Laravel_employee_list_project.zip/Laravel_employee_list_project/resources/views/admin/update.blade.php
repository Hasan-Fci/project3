

<!DOCTYPE html>
<html lang="en" class="dark">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Admin Dashboard</title>
    <!-- ================= Favicon ================== -->
    <!-- Standard -->
    <link rel="shortcut icon" href="http://placehold.it/64.png/000/fff">
    <!-- Retina iPad Touch Icon-->
    <link rel="apple-touch-icon" sizes="144x144" href="http://placehold.it/144.png/000/fff">
    <!-- Retina iPhone Touch Icon-->
    <link rel="apple-touch-icon" sizes="114x114" href="http://placehold.it/114.png/000/fff">
    <!-- Standard iPad Touch Icon-->
    <link rel="apple-touch-icon" sizes="72x72" href="http://placehold.it/72.png/000/fff">
    <!-- Standard iPhone Touch Icon-->
    <link rel="apple-touch-icon" sizes="57x57" href="http://placehold.it/57.png/000/fff">
    <!-- Styles -->
    <link href="{{asset('assets/css/lib/chartist/chartist.min.css')}}" rel="stylesheet">
    <link href="{{asset('assets/css/lib/font-awesome.min.css')}}" rel="stylesheet">
    <link href="{{asset('assets/css/lib/themify-icons.css')}}" rel="stylesheet">
    <link href="{{asset('assets/css/lib/owl.carousel.min.css')}}" rel="stylesheet" />
    <link href="{{asset('assets/css/lib/owl.theme.default.min.css')}}" rel="stylesheet" />
    <link href="{{asset('assets/css/lib/weather-icons.css')}}" rel="stylesheet" />
    <link href="{{asset('assets/css/lib/menubar/sidebar.css')}}" rel="stylesheet">
    <link href="{{asset('assets/css/lib/bootstrap.min.css')}}" rel="stylesheet">
    <link href="{{asset('assets/css/lib/unix.css')}}" rel="stylesheet">
    <link href="{{asset('assets/css/style.css')}}" rel="stylesheet">
</head>

<body>

    <div class="sidebar sidebar-hide-to-small sidebar-shrink sidebar-gestures">
        <div class="nano">
            <div class="nano-content">
                <ul>
                    <li class="label">Main</li>
                    <li class="active"><a href="{{URL::to('/admin')}}" class="sidebar-sub-toggle"><i class="ti-home"></i> Dashboard</a>
                    </li>
                    
                    <li><a class="sidebar-sub-toggle"><i class="ti-pencil-alt"></i>Employee <span class="badge badge-primary">2</span><span class="sidebar-collapse-icon ti-angle-down"></span></a>
                        <ul>
                            <li><a href="{{URL::to('/all_employee')}}">All Employee</a></li>
                            <li><a href="{{URL::to('/employee')}}">Add Employee</a></li>
                            
                        </ul>
                    </li>

                  </ul>
            </div>
        </div>
    </div>
    <!-- /# sidebar -->


    <div class="header">
        <div class="pull-left">
            <div class="logo"><a href="{{URL::to('/admin')}}"><!-- <img src="assets/images/logo.png" alt="" /> --><span>Employee Management</span></a></div>
            <div class="hamburger sidebar-toggle">
                <span class="line"></span>
                <span class="line"></span>
                <span class="line"></span>
            </div>
        </div>
        <div class="pull-right p-r-15">
            <ul>
                <li class="header-icon dib"><a href="#search"><i class="ti-search"></i></a></li>
                <li class="header-icon dib"><i class="ti-bell"></i>

                </li>
                <li class="header-icon dib"><i class="ti-email"></i>
                    
                </li>
                <li class="header-icon dib"><img class="avatar-img" src="assets/images/avatar/1.jpg" alt="" /> <span class="user-avatar">Motaleb &nbsp;<i class="ti-angle-down f-s-10"></i></span>
                    <div class="drop-down dropdown-profile">

                        <div class="dropdown-content-body">
                            <ul>
                                <li><a href="#"><i class="ti-user"></i> <span>Profile</span></a></li>                              
                                <li><a href="#"><i class="ti-settings"></i> <span>Setting</span></a></li>
                                <li><a href="#"><i class="ti-power-off"></i> <span>Logout</span></a></li>
                            </ul>
                        </div>
                    </div>
                </li>
            </ul>
        </div>
    </div>
    <div class="content-wrap">
        <div class="main">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-8 p-r-0 title-margin-left">
                        <div class="page-header">
                            <div class="page-title">
                                <h1 class="color-primary">Update Employee</h1>
                            </div>
                        </div>
<?php
    $massage=Session::get('massage');
    if($massage)
    {
?>
        <div class="page-header col-lg-5 text-center color-primary">
            <h1><?=$massage?></h1>
        </div>
<?php
    }
    Session::put('massage',null);
?>                   
                    </div>
                    <!-- /# column -->
                    <div class="col-lg-4 p-l-0 title-margin-left">
                        <div class="page-header">
                            <div class="page-title">
                                <ol class="breadcrumb text-right">
                                    <li class="active">Employee</li>
                                    <li><a href="{{URL::to('/admin')}}">Dashboard</a></li>
                                </ol>
                            </div>
                        </div>
                    </div>
                    <!-- /# column -->
                </div>
                <!-- /# row -->
                <div id="main-content">
<!--                     ############################################################################
    Content hear
-->

         








         

<div class="container-fulid">
    <div class="employee_add_section w-90 ">
        <form method="post" action="{{URL::to('/updateprocess')}}">
            {{ csrf_field() }}
            <div class="form-group">
                <label>Employee Name</label>
                <input type="text" class="form-control" value="{{$emp->Name}}" name="emp_name">
            </div>
            <div class="form-group">
                <label>Employee Email Address</label>
                <input type="email" class="form-control" value="{{$emp->Email}}" name="emp_email">
            </div>
            <div class="form-group">
                <label>Employee Position</label>
                <select name="emp_pst" class="form-control">
                    <option>{{$emp->Position}}</option>
                    <option>Jr. Developer</option>
                    <option>CEO</option>
                    <option>Manager</option>
                    <option>Developer</option>
                </select>                
            </div>
            <div class="form-group">
                <label>Employee Address</label>
                <input type="text" class="form-control" value="{{$emp->Address}}" name="emp_adrs">
            </div>
            <div class="form-group">
                <label>Employee Phone Number</label>
                <input type="number" class="form-control" value="{{$emp->Phone}}" name="emp_nmbr">
            </div>
            <input type="hidden" name="id" value="{{$emp->id}}">
            <button type="submit" name="submit" class="btn btn-primary">Update Employee</button>
        </form>
    </div>
</div>





<!--
############################################################################ -->
                </div>
            </div>
        </div>
    </div>

    <div id="search">
        <button type="button" class="close">×</button>
        <form>
            <input type="search" value="" placeholder="type keyword(s) here" />
            <button type="submit" class="btn btn-primary">Search</button>
        </form>
    </div>


    </div>
    <script src="{{asset('assets/js/lib/jquery.min.js')}}"></script>
    <!-- jquery vendor -->
    <script src="{{asset('assets/js/lib/jquery.nanoscroller.min.js')}}"></script>
    <!-- nano scroller -->
    <script src="{{asset('assets/js/lib/menubar/sidebar.js')}}"></script>
    <script src="{{asset('assets/js/lib/preloader/pace.min.js')}}"></script>
    <!-- sidebar -->
    <script src="{{asset('assets/js/lib/bootstrap.min.js')}}"></script>
    <!-- bootstrap -->
    <script src="{{asset('assets/js/lib/weather/jquery.simpleWeather.min.js')}}"></script>
    <script src="{{asset('assets/js/lib/weather/weather-init.js')}}"></script>
    <script src="{{asset('assets/js/lib/circle-progress/circle-progress.min.js')}}"></script>
    <script src="{{asset('assets/js/lib/circle-progress/circle-progress-init.js')}}"></script>
    <script src="{{asset('assets/js/lib/chartist/chartist.min.js')}}"></script>
    <script src="{{asset('assets/js/lib/chartist/chartist-init.js')}}"></script>
    <script src="{{asset('assets/js/lib/sparklinechart/jquery.sparkline.min.js')}}"></script>
    <script src="{{asset('assets/js/lib/sparklinechart/sparkline.init.js')}}"></script>
    <script src="{{asset('assets/js/lib/owl-carousel/owl.carousel.min.js')}}"></script>
    <script src="{{asset('assets/js/lib/owl-carousel/owl.carousel-init.js')}}"></script>
    <script src="{{asset('assets/js/scripts.js')}}"></script>
</body>

</html>