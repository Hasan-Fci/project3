<?php

Route::get('/', function () {
	return view('admin.admin_home');
	//return view('home');
});

Route::get('/admin', 'myctrl@adminview');
Route::get('/employee', 'myctrl@employee');
Route::get('/all_employee', 'myctrl@listemployee');
Route::post('/save_employee', 'myctrl@save_employee');

Route::get('/all_employee', 'myctrl@all_list');
Route::get('/delete_employee/{id}', 'myctrl@delete_employee');
Route::get('/update_employee/{id}', 'myctrl@update_employee');
Route::post('/updateprocess', 'myctrl@update');
