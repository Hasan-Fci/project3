
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
    <style>
        input{
            width: 99%;
        }
        .wt{
            width: 10%;
            padding: 10px 0px;
        }
    </style>
</head>
<body>
    <form action="<?php echo e(url('')); ?>" method="POST">
        <table border="1px" width="100%">
            <tr>
                <td>Name </td>
                <td>Email </td>
                <td>Address </td>
                <td>Phone </td>
            </tr>
            <tr>
                <td><input type="text" name="name"></td>
                <td><input type="text" name="email"></td>
                <td><input type="text" name="address"></td>
                <td><input type="text" name="phone"></td>
            </tr>
            <tr>
                <td colspan="4" align="center"><input class="wt" type="submit" value="Add Contact"></td>
            </tr>
        </table>
    </form>
</body>
</html>